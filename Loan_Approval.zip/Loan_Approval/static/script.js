document.getElementById("loanForm").addEventListener("submit", function(e){

let numbers=document.querySelectorAll("input[type='number']");

for(let i=0;i<numbers.length;i++){

if(numbers[i].value<0){

alert("Negative values are not allowed.");

e.preventDefault();

return;

}

}

});
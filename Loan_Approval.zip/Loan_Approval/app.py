from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open("Loan_model.pkl", "rb"))

try:
    scaler = pickle.load(open("scaler.pkl", "rb"))
except:
    scaler = None

gender_map = {"Male":1,"Female":0}
married_map = {"Yes":1,"No":0}
dependents_map = {"0":0,"1":1,"2":2,"3+":3}
education_map = {"Graduate":0,"Not Graduate":1}
selfemp_map = {"No":0,"Yes":1}
property_map = {"Rural":0,"Semiurban":1,"Urban":2}

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():

    gender = gender_map[request.form['gender']]
    married = married_map[request.form['married']]
    dependents = dependents_map[request.form['dependents']]
    education = education_map[request.form['education']]
    self_emp = selfemp_map[request.form['self_employed']]
    applicant_income = float(request.form['applicant_income'])
    coapplicant_income = float(request.form['coapplicant_income'])
    loan_amount = float(request.form['loan_amount'])
    loan_term = float(request.form['loan_term'])
    credit_history = float(request.form['credit_history'])
    property_area = property_map[request.form['property_area']]

    features = np.array([[gender,
                          married,
                          dependents,
                          education,
                          self_emp,
                          applicant_income,
                          coapplicant_income,
                          loan_amount,
                          loan_term,
                          credit_history,
                          property_area]])

    if scaler:
        features = scaler.transform(features)

    prediction = model.predict(features)[0]

    if prediction == 1:
        result = "Loan Approved"
        color = "green"
    else:
        result = "Loan Rejected"
        color = "red"

    return render_template(
        "index.html",
        prediction=result,
        color=color
    )

if __name__ == "__main__":
    app.run(debug=True)
from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open("RF_model.pkl", "rb"))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():

    features = [
        float(request.form["HighBP"]),
        float(request.form["HighChol"]),
        float(request.form["CholCheck"]),
        float(request.form["BMI"]),
        float(request.form["Smoker"]),
        float(request.form["Stroke"]),
        float(request.form["Diabetes"]),
        float(request.form["PhysActivity"]),
        float(request.form["HvyAlcoholConsump"]),
        float(request.form["MentHlth"]),
        float(request.form["PhysHlth"]),
        float(request.form["Sex"]),
        float(request.form["Age"]),
        float(request.form["Education"]),
        float(request.form["Income"])
    ]

    prediction = model.predict([features])[0]
    probability = model.predict_proba([features])[0][prediction]

    if prediction == 1:
        result = "High Risk of Heart Disease"
        color = "red"
    else:
        result = "Low Risk of Heart Disease"
        color = "green"

    return render_template(
        "index.html",
        prediction=result,
        probability=round(probability*100,2),
        color=color
    )

if __name__ == "__main__":
    app.run(debug=True)
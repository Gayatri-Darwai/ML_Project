const inputs = document.querySelectorAll("input");

inputs.forEach(input=>{

input.addEventListener("focus",()=>{

input.style.border="2px solid #0984e3";

});

input.addEventListener("blur",()=>{

input.style.border="1px solid gray";

});

});
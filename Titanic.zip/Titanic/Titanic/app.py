from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open("Titanic_model.pkl", "rb"))


@app.route('/')
def home():
    return render_template("index.html")


@app.route('/predict', methods=["POST"])
def predict():

    pclass = int(request.form["Pclass"])
    sex = int(request.form["Sex"])
    sibsp = int(request.form["SibSp"])
    parch = int(request.form["Parch"])

    features = np.array([[pclass, sex, sibsp, parch]])

    prediction = model.predict(features)[0]

    probability = None

    try:
        probability = model.predict_proba(features)[0][prediction]
        probability = round(probability * 100, 2)
    except:
        probability = None

    if prediction == 1:
        result = "Passenger Survived"
        color = "success"
    else:
        result = "Passenger Did Not Survive"
        color = "danger"

    return render_template(
        "index.html",
        prediction=result,
        color=color,
        probability=probability
    )


if __name__ == "__main__":
    app.run(debug=True)
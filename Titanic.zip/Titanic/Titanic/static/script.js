const form = document.getElementById("predictionForm");

form.addEventListener("submit",function(){

const btn=document.querySelector("button");

btn.innerHTML="Predicting...";

btn.disabled=true;

});

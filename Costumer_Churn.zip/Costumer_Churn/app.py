from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open("cc_model.pkl", "rb"))

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():

    customer = float(request.form["customer"])
    age = float(request.form["age"])
    usage = float(request.form["usage"])
    support = float(request.form["support"])
    spend = float(request.form["spend"])

    features = np.array([[customer,
                          age,
                          usage,
                          support,
                          spend]])

    prediction = model.predict(features)

    if prediction[0] == 1:
        result = "⚠ Customer is Likely to Churn"
        color = "red"
    else:
        result = "✅ Customer is Not Likely to Churn"
        color = "green"

    return render_template("index.html",
                           prediction=result,
                           color=color)


if __name__ == "__main__":
    app.run(debug=True)
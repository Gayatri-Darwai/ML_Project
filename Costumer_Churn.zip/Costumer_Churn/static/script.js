const inputs = document.querySelectorAll("input");

inputs.forEach(input=>{

input.addEventListener("focus",()=>{

input.style.background="#eef8ff";

});

input.addEventListener("blur",()=>{

input.style.background="white";

});

});

document.getElementById("resetBtn").addEventListener("click",()=>{

setTimeout(()=>{

const result=document.querySelector(".result");

if(result){

result.innerHTML="";

}

},100);

});
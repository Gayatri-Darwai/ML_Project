const form = document.getElementById("predictionForm");

const loading = document.getElementById("loading");

form.addEventListener("submit",function(){

loading.style.display="block";

});

from flask import Flask, render_template, request, jsonify
import pickle
import numpy as np

app = Flask(__name__)

# Load Model
model = pickle.load(open("diabetes_model.pkl","rb"))

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():

    try:
        data = request.json

        features = np.array([[
            float(data["Pregnancies"]),
            float(data["Glucose"]),
            float(data["BloodPressure"]),
            float(data["SkinThickness"]),
            float(data["Insulin"]),
            float(data["BMI"]),
            float(data["Age"])
        ]])

        prediction = model.predict(features)[0]

        probability = None

        if hasattr(model,"predict_proba"):
            probability = round(model.predict_proba(features)[0][1]*100,2)

        if prediction==1:
            result="High Risk of Diabetes"
        else:
            result="Low Risk of Diabetes"

        return jsonify({
            "prediction":result,
            "probability":probability
        })

    except Exception as e:
        return jsonify({"error":str(e)})


if __name__=="__main__":
    app.run(debug=True)
function predict(){

let data={

Pregnancies:document.getElementById("Pregnancies").value,

Glucose:document.getElementById("Glucose").value,

BloodPressure:document.getElementById("BloodPressure").value,

SkinThickness:document.getElementById("SkinThickness").value,

Insulin:document.getElementById("Insulin").value,

BMI:document.getElementById("BMI").value,

Age:document.getElementById("Age").value

};

for(let key in data){

if(data[key]==""){

alert("Please fill all fields");

return;

}

}

document.getElementById("loading").style.display="block";

fetch("/predict",{

method:"POST",

headers:{

"Content-Type":"application/json"

},

body:JSON.stringify(data)

})

.then(response=>response.json())

.then(result=>{

document.getElementById("loading").style.display="none";

let html="";

if(result.prediction=="High Risk of Diabetes"){

html="<div class='danger'>❌ "+result.prediction+"</div>";

}else{

html="<div class='success'>✅ "+result.prediction+"</div>";

}

if(result.probability!=null){

html+="<br><br>Risk Probability : "+result.probability+"%";

}

document.getElementById("result").innerHTML=html;

});

}

function resetForm(){

document.querySelectorAll("input").forEach(input=>{

input.value="";
});

document.getElementById("result").innerHTML="";
}

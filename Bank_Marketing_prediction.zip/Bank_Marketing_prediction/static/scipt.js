const form=document.querySelector("form");

form.addEventListener("submit",function(){

document.querySelector(".predict-btn").innerHTML="Predicting...";

});

const inputs=document.querySelectorAll("input");

inputs.forEach(input=>{

input.addEventListener("input",()=>{

if(input.value<0){

input.style.borderColor="red";

}else{

input.style.borderColor="#2563eb";

}

});

});
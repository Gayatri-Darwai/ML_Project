from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open("bm_model.pkl", "rb"))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():

    age = float(request.form["age"])
    balance = float(request.form["balance"])
    day = float(request.form["day"])
    duration = float(request.form["duration"])
    campaign = float(request.form["campaign"])
    pdays = float(request.form["pdays"])

    prediction = model.predict([[age, balance, day, duration, campaign, pdays]])

    result = prediction[0]

    return render_template(
        "index.html",
        prediction_text=f"Predicted Previous Contact Value : {result}"
    )

if __name__ == "__main__":
    app.run(debug=True)
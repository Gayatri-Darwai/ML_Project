from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

model = pickle.load(open("insurance_model.pkl", "rb"))


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():

    age = float(request.form["age"])
    sex = int(request.form["sex"])
    bmi = float(request.form["bmi"])
    children = int(request.form["children"])
    smoker = int(request.form["smoker"])
    region = int(request.form["region"])
    charges = float(request.form["charges"])

    features = np.array([[age,
                          sex,
                          bmi,
                          children,
                          smoker,
                          region,
                          charges]])

    prediction = model.predict(features)[0]

    if prediction == 1:
        result = "Insurance Claim Approved ✅"
    else:
        result = "Insurance Claim Not Approved ❌"

    return render_template("index.html",
                           prediction_text=result)


if __name__ == "__main__":
    app.run(debug=True)
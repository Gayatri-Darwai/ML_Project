const form=document.getElementById("predictionForm");

const btn=document.getElementById("predictBtn");

form.addEventListener("submit",function(){

btn.innerHTML="Predicting...";

btn.disabled=true;

});